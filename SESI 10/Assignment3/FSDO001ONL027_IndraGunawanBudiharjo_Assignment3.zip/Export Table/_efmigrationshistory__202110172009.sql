INSERT INTO movies.`__efmigrationshistory` (MigrationId,ProductVersion) VALUES
	 ('20211016143351_Initial Migrations','5.0.11'),
	 ('20211017034249_Addingauthentication to movies API','5.0.11');