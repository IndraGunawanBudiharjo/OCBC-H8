INSERT INTO movies.movies (Name,Genre,Duration,ReleaseDate) VALUES
	 ('Bad Boys for Life','Action/Comedy','2h 5 mins','2020-01-23 00:00:00'),
	 ('John Wick','Action/Thriller','1h 41 mins','2014-10-24 00:00:00'),
	 ('The Wailing','Mistery/Thriller','2h 36 mins','2016-05-12 00:00:00'),
	 ('Malignant','Horror/Thriller','1h 51 mins','2021-10-06 00:00:00');