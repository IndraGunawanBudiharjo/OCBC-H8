using Movies.Configuration;

namespace Movies.Models.DTOs.Responses
{
    public class RegistrationResponse : AuthResult
    {
        
    }
}